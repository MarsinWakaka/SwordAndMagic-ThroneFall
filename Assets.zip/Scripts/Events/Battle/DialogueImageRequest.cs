using System;
using MyFramework.Utilities;
using UnityEngine;

namespace Events.Battle
{
    public class DialogueImageRequest : IEventArgs
    {
        public string ImageName;
        public Action<Sprite> OnImageReady;

        public DialogueImageRequest(
            string imageName,  
            Action<Sprite> onImageReady)
        {
            ImageName = imageName;
            OnImageReady = onImageReady;
        }
    }
}