using GameLogic.Unit.Controller;
using MyFramework.Utilities;
using UnityEngine;

namespace Events.Battle
{
    public class UnitMoveArgs : IEventArgs
    {
        public readonly EntityController BaseEntity;
        public readonly Vector2Int OldPosition;
        public readonly Vector2Int TargetPosition;
        
        public UnitMoveArgs(EntityController baseEntity, Vector2Int oldPosition, Vector2Int targetPosition)
        {
            BaseEntity = baseEntity;
            OldPosition = oldPosition;
            TargetPosition = targetPosition;
        }
    }
}