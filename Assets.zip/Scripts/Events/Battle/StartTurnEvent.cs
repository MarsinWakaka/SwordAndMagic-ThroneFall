using MyFramework.Utilities;

namespace Events.Battle
{
    public struct StartTurnEvent : IEventArgs
    {
        public int Round { get; }
        
        public StartTurnEvent(int round)
        {
            Round = round;
        }
    }
}