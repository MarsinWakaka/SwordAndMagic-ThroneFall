using System;
using MyFramework.Utilities;

namespace Events.Battle
{
    
    public class PlayerTurnEventArgs : IEventArgs
    {
        public int Round;
        /// <summary>
        /// 玩家回合结束回调
        /// </summary>
        public readonly Action OnComplete;
        public PlayerTurnEventArgs(int round, Action onComplete)
        {
            Round = round;
            OnComplete = onComplete;
        }
    }
}