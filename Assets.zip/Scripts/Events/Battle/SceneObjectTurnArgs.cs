using System;
using MyFramework.Utilities;

namespace Events.Battle
{
    public class SceneObjectTurnArgs : IEventArgs
    {
        public int Round;
        public Action OnComplete;
        
        public SceneObjectTurnArgs(int curRound, Action onComplete)
        {
            Round = curRound;
            OnComplete = onComplete;
        }
    }
}