using GameLogic.Unit.Controller;
using MyFramework.Utilities;

namespace Events.Battle
{
    public class UnitSpawnedEvent : IEventArgs
    {
        public EntityController Unit { get; }
        
        public UnitSpawnedEvent(EntityController unit)
        {
            Unit = unit;
        }
    }
}