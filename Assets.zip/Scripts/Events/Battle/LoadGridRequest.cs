using System.Collections.Generic;
using GameLogic.Map;
using MyFramework.Utilities;

namespace Events.Battle
{
    public class LoadGridRequest : IEventArgs
    {
        public List<SpawnGridRecord> Records { get; }
        
        public LoadGridRequest(List<SpawnGridRecord> records)
        {
            Records = records;
        }
    }
}