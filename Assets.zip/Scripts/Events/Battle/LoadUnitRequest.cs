using System.Collections.Generic;
using GameLogic.Map;
using MyFramework.Utilities;

namespace Events.Battle
{
    /// <summary>
    /// 角色生成事件参数(只需要ID 和 位置)
    /// </summary>
    public class LoadUnitRequest : IEventArgs
    {
        public readonly List<SpawnUnitRecord> UnitSpawnRequests;
        public LoadUnitRequest(List<SpawnUnitRecord> unitSpawnRequests)
        {
            UnitSpawnRequests = unitSpawnRequests;
        }
    }
}