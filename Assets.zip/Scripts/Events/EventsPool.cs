namespace Events
{
    public static class EventsPool
    {
        
    }
}