namespace Events
{
    // 事件类型枚举（可按需扩展）
    public static class GameEvent
    {
        public const string LoadGridRequest = "LoadGridRequest";
        public const string UnitSpawnRequest = "UnitSpawnRequest";
        public const string LoadDialogueRequest = "LoadDialogueRequest";
        
        public const string UnitSpawn = "UnitSpawn";
        public const string UnitDespawn = "UnitDespawn";
        public const string UnitMove = "CharacterMove";
        public const string CharacterAttack = "CharacterAttack";
        public const string CharacterDie = "CharacterDie";
        public const string CharacterSkill = "CharacterSkill";
        
        public const string StartTurn = "StartTurn";
        public const string TriggerSceneEvent = "TriggerSceneEvent";
        public const string PlayerTurn = "PlayerTurn";
        public const string EnemyTurn = "EnemyTurn";
        public const string SceneObjectTurn = "SceneObjectTurn";
        public const string EndTurn = "EndTurn";
        
        public const string GameStart = "GameStart";
        public const string GameOver = "GameOver";
        
        public const string SceneLoad = "SceneLoad";
        /// <summary>
        /// 通过对话文件的ID字符串去加载对话文件，对应的事件类名为 LoadDialogueEvent
        /// </summary>
        public const string DialogueRequest = "DialogueRequest";
        public const string CharacterExpressionRequest = "CharacterExpressionRequest";
        public const string DialogueImageRequest = "DialogueImageRequest";
    }
}