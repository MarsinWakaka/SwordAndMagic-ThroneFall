namespace UI
{
    // ReSharper disable once ClassNeverInstantiated.Global
    public class PanelName
    {
        // 全局
        public const string MainMenuPanel = "MainMenuPanel";
        public const string LoadingPanel = "LoadingPanel";
        public const string MainLobbyPanel = "MainLobbyPanel";
        public const string NavigationPanel = "NavigationPanel";
        public const string SettingsPanel = "SettingsPanel";
        public const string InventoryPanel = "InventoryPanel";
        public const string CharacterDetailPanel = "CharacterDetailPanel";
        public const string CharacterSkillDetailPanel = "CharacterSkillDetailPanel";
        public const string CharacterPanel = "CharacterPanel";
        
        // 战斗
        public const string BattlePanel = "BattlePanel";
        public const string BattleInfoPanel = "BattleInfoPanel";
        public const string BattleDialoguePanel = "BattleDialoguePanel";
    }
}