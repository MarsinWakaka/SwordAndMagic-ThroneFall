using UnityEngine;

// namespace UI
// {
//     // 通过配置文件来配置面板的属性
//     // [TODO] 面板具体逻辑使用Lua脚本来实现
//     [CreateAssetMenu(menuName = "UI/PanelConfig", order = 1)]
//     public class UIPanelConfig : ScriptableObject
//     {
//         // 默认禁用其它面板的输入
//         // 模态窗口：没关闭前，能否对其他窗口进行操作
//         // public bool isModal;
//         
//         // 是否阻挡其它面板的输入
//         public bool blockInput = true;
//         
//         public UILayer layer;
//         
//         public AutoClose autoClose;
//     }
// }