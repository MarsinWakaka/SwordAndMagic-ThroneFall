using UnityEngine;
using UnityEngine.UI;

namespace UI.ConcretePanel
{
    public class CharacterDetailParams
    {
        public string CharacterId;
    }

    public class CharacterDetailPanel : BaseUIPanel
    {
        [SerializeField] private Button backButton;
        [SerializeField] private Button characterSkillDetailPanel;

        private void Awake()
        {
            backButton.onClick.AddListener(() => { UIManager.Instance.ClosePanel(PanelName.CharacterDetailPanel); });

            characterSkillDetailPanel.onClick.AddListener(() =>
            {
                UIManager.Instance.ShowPanel(PanelName.CharacterSkillDetailPanel, OpenStrategy.HideCurrent,
                    new CharacterSkillDetailParams()
                    {
                        SkillId = "技能A"
                    });
            });
        }
    }
}