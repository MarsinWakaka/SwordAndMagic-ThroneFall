using UnityEngine;
using UnityEngine.UI;

namespace UI.ConcretePanel
{
    public class MainLobbyPanel : BaseUIPanel
    {
        [SerializeField] private Button characterButton;
        [SerializeField] private Button navigationButton;
        
        private void Awake()
        {
            characterButton.onClick.AddListener(() =>
            {
                UIManager.Instance.ShowPanel(PanelName.CharacterPanel, OpenStrategy.HideCurrent);
            });
            
            navigationButton.onClick.AddListener(() =>
            {
                UIManager.Instance.ShowPanel(PanelName.NavigationPanel, OpenStrategy.HideCurrent);
            });
        }
    }
}