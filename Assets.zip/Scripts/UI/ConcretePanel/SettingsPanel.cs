using UnityEngine;
using UnityEngine.UI;

namespace UI.ConcretePanel
{
    public class SettingsPanel : BaseUIPanel
    {
        [SerializeField] private Button backButton;
        
        private void Awake()
        {
            backButton.onClick.AddListener(() => { UIManager.Instance.ClosePanel(PanelName.SettingsPanel); });
        }
    }
}