using UnityEngine;
using UnityEngine.UI;

namespace UI.ConcretePanel.Battle
{
    public class DeployPanel : BaseUIPanel
    {
        // 作战开始按钮
        [SerializeField] private Button battleStartButton;
        
        public override void OnCreate(object data)
        {
            base.OnCreate(data);
            // 请求玩家数据
            
            
        }
    }
}