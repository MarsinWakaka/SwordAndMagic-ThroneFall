using System;
using UnityEngine;
using UnityEngine.UI;

namespace UI.ConcretePanel.Battle
{
    public class BattleCharacterControlPanel : BaseUIPanel
    {
        [SerializeField] private Button endTurnButton;

        private void Awake()
        {
            endTurnButton.onClick.AddListener(OnEndTurnButtonClicked);
        }

        private void OnEndTurnButtonClicked()
        {
            
        }
    }
}