using UnityEngine;
using UnityEngine.UI;

namespace UI.ConcretePanel
{
    public class MainMenuPanel : BaseUIPanel
    {
        [SerializeField] private Button startButton;
        
        private void Awake()
        {
            startButton.onClick.AddListener(() =>
            {
                UIManager.Instance.ShowPanel(PanelName.MainLobbyPanel, OpenStrategy.ReplaceCurrent);
            });
        }
    }
}