using UnityEngine;
using UnityEngine.UI;

namespace UI.ConcretePanel
{
    public class CharacterPanel : BaseUIPanel
    {
        [SerializeField] private Button backButton;
        [SerializeField] private Button navigationButton;
        [SerializeField] private Button characterDetailPanel;

        private void Awake()
        {
            backButton.onClick.AddListener(() =>
            {
                UIManager.Instance.ClosePanel(PanelName.CharacterPanel);
            });
            navigationButton.onClick.AddListener(() =>
            {
                UIManager.Instance.ShowPanel(PanelName.NavigationPanel, OpenStrategy.ReplaceCurrent);
            });
            characterDetailPanel.onClick.AddListener(() =>
            {
                UIManager.Instance.ShowPanel(PanelName.CharacterDetailPanel, OpenStrategy.HideCurrent,
                    new CharacterDetailParams()
                    {
                        CharacterId = "Iraya"
                    });
            });
        }
    }
}