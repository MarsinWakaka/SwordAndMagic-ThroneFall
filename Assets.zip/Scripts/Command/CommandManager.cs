using UnityEngine;

namespace Command
{
    public class CommandManager : MonoBehaviour
    {
        // TODO MonoSingleton
        public static CommandManager Instance { get; private set; }
        
        
    }
}