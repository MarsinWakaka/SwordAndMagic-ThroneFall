using System;
using System.Collections;
using GameLogic.Unit;
using GameLogic.Unit.Controller;
using MyFramework.Utilities.Extensions;
using UnityEngine;

namespace GameLogic.Skill
{
    public class SkillSelectContext
    {
        public CharacterUnitController Caster;
        public CharacterUnitController Targets;
        public Vector2Int TargetGridCoord;
    }
    
    public class SkillReleaseContext
    {
        public CharacterUnitController Caster;
        public CharacterUnitController[] Targets;
        public Vector2Int[] TargetGridCoords;
    }
    
    public abstract class BaseSkill : ScriptableObject
    {
        [Header("静态技能信息")]
        public int skillID;
        public string skillName;
        public Sprite skillIcon;
        public UnitType canSelectType;
        public GameObject[] skillEffect;
        public AudioClip[] skillAudio;
        
        [Header("动态技能信息")]
        public Vector2Int attackRange;      // 攻击范围
        public Vector2Int allowHeightDiff;  // 允许的高度差
        public int selectCount;
        [Header("技能作用的范围 [xOffset, yOffset]")] 
        [SerializeField] private Vector2Int[] upDirScope = {Vector2Int.zero};
        public Vector2Int[] GetScopeByDir(Direction direction)
        {
            switch (direction)
            {
                case Direction.Up:
                    return upDirScope;
                case Direction.Down:
                    var downDirScope = new Vector2Int[upDirScope.Length];
                    for (var i = 0; i < downDirScope.Length; i++)
                    {
                        downDirScope[i] = downDirScope[i].Rotate180Degree();
                    }
                    return downDirScope;
                case Direction.Left:
                    var leftDirScope = new Vector2Int[upDirScope.Length];
                    for (var i = 0; i < leftDirScope.Length; i++)
                    {
                        leftDirScope[i] = leftDirScope[i].Rotate90Degree(false);
                    }
                    return leftDirScope;
                case Direction.Right:
                    var rightDirScope = new Vector2Int[upDirScope.Length];
                    for (var i = 0; i < rightDirScope.Length; i++)
                    {
                        rightDirScope[i] = rightDirScope[i].Rotate90Degree(true);
                    }
                    return rightDirScope;
            }
            return Array.Empty<Vector2Int>();
        }
        
        public abstract string GetSkillDescription();
        
        public abstract bool IsSelectValid(SkillSelectContext selectContext);
        
        public abstract IEnumerator Execute(SkillReleaseContext releaseContext);
    }
}