using System.Collections;

namespace GameLogic.Skill.ConcreteSkill
{
    public class TeleportSkill : BaseSkill
    {
        public override string GetSkillDescription() => "将施法者传送到指定位置";
        public override bool IsSelectValid(SkillSelectContext selectContext)
        {
            throw new System.NotImplementedException();
        }

        public override IEnumerator Execute(SkillReleaseContext releaseContext)
        {
            throw new System.NotImplementedException();
        }

        public void SetValues(int[] values)
        {
            throw new System.NotImplementedException();
        }
    }
}