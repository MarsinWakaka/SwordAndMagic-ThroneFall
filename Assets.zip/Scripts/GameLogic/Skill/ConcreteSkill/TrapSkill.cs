using System.Collections;
using GameLogic.Grid;
using GameLogic.Unit.Controller;
using GameLogic.Unit.Data;
using MyFramework.Utilities;
using UnityEngine;
using UnityEngine.Serialization;

namespace GameLogic.Skill.ConcreteSkill
{
    [CreateAssetMenu(fileName = "TrapSkill", menuName = "Skill/TrapSkill")]
    public class TrapSkill : BaseSkill, IUpgradable
    {
        [FormerlySerializedAs("staticTrapData")] public TrapStaticData entityStaticTrapData;
        
        public void SetValues(int[] values)
        {
            throw new System.NotImplementedException();
        }

        public override string GetSkillDescription()
        {
            throw new System.NotImplementedException();
        }

        public override bool IsSelectValid(SkillSelectContext selectContext)
        {
            throw new System.NotImplementedException();
        }

        public override IEnumerator Execute(SkillReleaseContext releaseContext)
        {
            // TODO 指定位置生成一个陷阱
            for(int i = 0; i < selectCount; i++)
            {
                var selectedCoord = releaseContext.TargetGridCoords[i];
                var casterCoord = releaseContext.Caster.EntityData.gridCoord;
                // TODO 播放音效
                // TODO 播放特效
                var gridService = ServiceLocator.GetService<IGridDataProvider>();
                var worldPos = gridService.QueryUnitWorldPos(selectedCoord);
                // TODO 生成陷阱
                var trap = Instantiate(entityStaticTrapData.prefab).GetComponent<TrapController>();
                trap.transform.position = worldPos;
                trap.Initialize(entityStaticTrapData, selectedCoord, Direction.Up);
            }
            yield return null;
        }
    }
}