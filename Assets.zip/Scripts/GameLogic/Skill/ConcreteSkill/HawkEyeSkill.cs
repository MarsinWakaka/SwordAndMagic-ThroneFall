using System.Collections;
using GameLogic.TriggerSystem;
using GameLogic.Unit;
using GameLogic.Unit.Controller;
using GameLogic.Unit.Data;
using MyFramework.Utilities;
using MyFramework.Utilities.Extensions;
using UnityEngine;
using Utilities;

namespace GameLogic.Skill.ConcreteSkill
{
    [CreateAssetMenu(fileName = "HawkEyeSkill", menuName = "Skill/HawkEyeSkill")]
    public class HawkEyeSkill : BaseSkill
    {
        /// <summary>
        /// 监视回合数
        /// </summary>
        public int duration; 
        /// <summary>
        /// 最大触发次数
        /// </summary>
        public int maxTriggerCount;
        /// <summary>
        /// 能够触发该技能的单位类型
        /// </summary>
        public UnitType canTriggerUnitType; 
        
        public override string GetSkillDescription() => "监视指定区域，若有敌人进入区域或者在区域内做出动作，则做出反击";
        
        public override bool IsSelectValid(SkillSelectContext selectContext)
        {
            throw new System.NotImplementedException();
        }

        public override IEnumerator Execute(SkillReleaseContext releaseContext)
        {
            var selectedPosition = releaseContext.TargetGridCoords[0];
            var casterPosition = releaseContext.Caster.EntityData.gridCoord;
            var direction = DirectionUtil.GetDirection(casterPosition, selectedPosition); 
            // TODO 播放音效
            // TODO 播放特效
            // TODO（完善参数配置） 监视区域(往触发器管理器注册监听)
            var trigger = new Trigger( duration, maxTriggerCount )
            {
                TriggerPositions = GetScopeByDir(direction).ToHashSet(),
                OnTriggered = HandleTriggered,
            };
            ServiceLocator.GetService<ITriggerService>().RegisterTrigger(trigger);
            yield return null;
        }
        
        private IEnumerator HandleTriggered(EntityController controller)
        {
            // TODO 播放音效
            // TODO 播放特效
            // TODO 反击
            yield return null;
        }

        public void SetValues(int[] values)
        {
            throw new System.NotImplementedException();
        }
    }
}