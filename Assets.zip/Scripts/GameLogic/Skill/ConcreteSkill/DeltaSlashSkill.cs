using System.Collections;
using UnityEngine;

namespace GameLogic.Skill.ConcreteSkill
{
    [CreateAssetMenu(fileName = "DeltaSlashSkill", menuName = "Skill/DeltaSlashSkill", order = 1)]
    public class DeltaSlashSkill : BaseSkill
    {
        public int damage;

        public override string GetSkillDescription()
        {
            return "对范围内的目标造成" + damage + "点伤害";
        }

        public override bool IsSelectValid(SkillSelectContext selectContext)
        {
            throw new System.NotImplementedException();
        }

        public void SetValues(int[] values)
        {
            
        }

        public override IEnumerator Execute(SkillReleaseContext releaseContext)
        {
            // 播放音效
            // 播放特效
            foreach (var target in releaseContext.Targets)
            {
                // 伤害命令
            }
            yield return null;
        }
    }
}