namespace GameLogic.Skill
{
    public class SkillSystem
    {
        
    }
}