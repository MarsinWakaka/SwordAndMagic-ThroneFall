using System;

namespace GameLogic
{
    [Serializable]
    public struct UpgradeRecord
    {
        /// <summary>
        /// 升级到下等级所需的消耗
        /// </summary>
        public int cost;
        
        /// <summary>
        /// 数值列表
        /// </summary>
        public int[] values;
    }
}