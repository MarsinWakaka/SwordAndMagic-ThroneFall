using UnityEngine;

namespace GameLogic.Task
{
    [CreateAssetMenu(menuName = "Battle/Tasks/UnitSurvive", order = 0)]
    public class UnitSurviveTask : BaseTask
    {
        [Header("Task Settings")]
        public int unitID;
        
        public override bool IsTaskCompleted(BattleContext context)
        {
            throw new System.NotImplementedException();
        }
    }
}