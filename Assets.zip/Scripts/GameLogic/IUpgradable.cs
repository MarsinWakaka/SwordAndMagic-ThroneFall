namespace GameLogic
{
    public interface IUpgradable
    {
        public void SetValues(int[] values);
    }
}