using Events;
using Events.Battle;
using GameLogic.Grid;
using GameLogic.Map;
using GameLogic.Unit.Manager;
using MyFramework.Utilities;
using UnityEngine;

namespace GameLogic.Battle
{
    public class BattleSystem : MonoBehaviour
    {
        [Header("服务注册区")]
        [SerializeField] private UnitManager unitManager;
        [SerializeField] private GridManager gridManager;

        private void OnEnable()
        {
            // 注册服务
            // TODO 完成其它服务的注册 
            ServiceLocator.Register<IGridDataProvider>(gridManager);
            ServiceLocator.Register<IUnitDataProvider>(unitManager);
        }

        private void OnDisable()
        {
            // 注销服务
            // TODO 完成其它服务的注销
            ServiceLocator.UnRegister<IGridDataProvider>(gridManager);
            ServiceLocator.UnRegister<IUnitDataProvider>(unitManager);
        }

        private void Start()
        {
            // 调用MapLoader加载游戏场景
            var mapContext = new MapLoader().LoadMap(1, 1);
            
            // 事件通知
            var battleChannel = EventBus.Channel(Channel.Battle);
            // 1.初始化地图
            battleChannel.Publish(GameEvent.LoadGridRequest, new LoadGridRequest(mapContext.grids));
            // 2.单位管理器初始化
            battleChannel.Publish(GameEvent.UnitSpawnRequest, new LoadUnitRequest(mapContext.obstacles));
            battleChannel.Publish(GameEvent.UnitSpawnRequest, new LoadUnitRequest(mapContext.characters));

            battleChannel.Publish(GameEvent.LoadDialogueRequest, new LoadDialogueEvent(mapContext.dialogueId, () =>
            {
                battleChannel.Publish(GameEvent.StartTurn, new StartTurnEvent(1));
            }));
        }
    }
}