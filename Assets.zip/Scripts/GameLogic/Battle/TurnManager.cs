using System;
using Events;
using Events.Battle;
using MyFramework.Utilities;
using UnityEngine;

namespace GameLogic.Battle
{
    public class TurnManager : MonoBehaviour
    {
        // 遍历顺序
        // (回合开始) -> 场景事件 -> 玩家回合 -> 敌人回合 -> 场景物体 -> (回合结束)

        public void OnEnable()
        {
            EventBus.Channel(Channel.Battle).Subscribe<StartTurnEvent>(GameEvent.StartTurn, NextTurn);
        }

        public void OnDisable()
        {
            EventBus.Channel(Channel.Battle).Unsubscribe<StartTurnEvent>(GameEvent.StartTurn, NextTurn);
        }

        public int CurRound { get; private set; }

        public void Initialize()
        {
            CurRound = 0;
        }

        public void NextTurn(StartTurnEvent eventArgs)
        {
            CurRound = eventArgs.Round;
            // 回合开始 (通知回合更新)
            Debug.Log($"[Turn {eventArgs.Round}]");
            // 场景事件 (通知场景事件)
            EventBus.Channel(Channel.Battle).Publish(GameEvent.TriggerSceneEvent,
                new TriggerSceneEventArgs(CurRound, () =>
                {
                    // TODO : Clear Undo Stack
                    // 玩家回合 (通知玩家回合)
                    EventBus.Channel(Channel.Battle).Publish(GameEvent.PlayerTurn,
                        new PlayerTurnEventArgs(CurRound, () =>
                        {
                            // TODO : Clear Undo Stack
                            // 敌人回合 (通知敌人回合)
                            EventBus.Channel(Channel.Battle).Publish(GameEvent.EnemyTurn,
                                new EnemyTurnArgs(CurRound, () =>
                                {
                                    // 场景物体 (通知场景物体)
                                    EventBus.Channel(Channel.Battle).Publish(GameEvent.SceneObjectTurn,
                                        new SceneObjectTurnArgs(CurRound, () =>
                                        {
                                            // 回合结束 (通知回合结束)
                                            NextTurn(new StartTurnEvent(CurRound + 1));
                                        }));
                                }));
                        }));
                }));
        }
    }
}