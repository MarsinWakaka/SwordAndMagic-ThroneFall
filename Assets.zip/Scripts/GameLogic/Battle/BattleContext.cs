
namespace GameLogic
{
    public class BattleContext
    {
        public int RoundCount;
        
        // public Dictionary<Faction, List<BaseUnitData>> Units;
        
        // 其它信息
    }
}