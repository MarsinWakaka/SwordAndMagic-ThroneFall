using System;
using System.Collections.Generic;
using Events;
using Events.Battle;
using GameLogic.Grid;
using GameLogic.InputProvider.PlayerInputState;
using GameLogic.Unit;
using GameLogic.Unit.Controller;
using GameLogic.Unit.Manager;
using MyFramework.Utilities;
using MyFramework.Utilities.FSM;
using UnityEngine;

namespace GameLogic.InputProvider
{
    public class PlayerInputProvider : MonoBehaviour
    {
        [SerializeField] private List<CharacterUnitController> playableCharacters;
        public Camera _viewCamera;
        
        public LayerMask _groundLayer;
        public LayerMask _entityLayer;
        
        public int RayCastLayer { get; set; }
        
        private void Awake()
        {
            _viewCamera = Camera.main;
            _fsm = new Fsm<InputState>(InputState.Inactive);
            _fsm.AddState(InputState.Select, new SelectState(this));
        }

        private void OnEnable()
        {
            // 注册玩家输入事件
            EventBus.Channel(Channel.Battle).Subscribe<PlayerTurnEventArgs>(GameEvent.PlayerTurn, OnPlayerTurnStart);
        }
        
        private void OnDisable()
        {
            // 注销玩家输入事件
            EventBus.Channel(Channel.Battle).Unsubscribe<PlayerTurnEventArgs>(GameEvent.PlayerTurn, OnPlayerTurnStart);
        }

        private void Update()
        {
            HandleTest();
            RaycastTarget();
            _fsm.UpdateFsm();
        }
        
        private enum InputState
        {
            Inactive,
            Select,
            MoveAction,
            AttackSelect,
            AttackConfirm
        }
        
        private Fsm<InputState> _fsm;

        private GridController _curHoverGrid;

        public void ShowMouseHoverStyleOnGrid()
        {
            // TODO 显示鼠标悬停在格子上时的样式
            var hitInfo = Physics2D.Raycast(
                _viewCamera.ScreenToWorldPoint(Input.mousePosition), Vector2.zero, 
                100f, _groundLayer);
            if (hitInfo.collider != null)
            {
                var gridCtrl = hitInfo.collider.GetComponent<GridController>();
                if (gridCtrl != null)
                {
                    _curHoverGrid?.OnCancelMouseHover();
                    _curHoverGrid = gridCtrl;
                    // TODO 显示鼠标悬停在格子上时的样式
                    _curHoverGrid.OnMouseHover();
                }
            }
            else
            {
                // TODO 清空鼠标悬停在格子上时的样式
                _curHoverGrid?.OnCancelMouseHover();
            }
        }

        private void RaycastTarget()
        {
            // if (Input.GetMouseButtonDown(0))
            // {
                // [选择状态] (允许碰撞图层为ground, entity)
                // 如果是地格则选中地格(状态不变)
                // 如果是玩家角色则选中玩家并进入[玩家操作状态]
                // 如果是敌方角色、障碍物则查看敌方角色的移动范围
                
                // [玩家操作状态] (允许碰撞图层为ground, entity)
                // 如果是地块且位于玩家移动范围内则进行判断地格上是否有物体
                // - 如果成立，则判断该物体类型
                // - - 如果是玩家角色[且该角色没有行动完毕]，且不是当前选中角色，则选中新角色
                // - - 如果是敌人、障碍物，则进入对应的查看界面
                // - - 如果是地格，则将角色显示在该位置，且进入[攻击选择状态]
                // - 如果不成立，则退出该状态
                // [退出] 清空角色显示
                
                // [攻击选择状态] (允许碰撞图层为ground, entity)
                // 如果选中的物体位置位于攻击范围内，则进行攻击类型以及阵营判断
                // - 如果符合类型以及阵营，则进入攻击确认状态
                // - 如果不符合类型或者阵营，则是简单显示地块选中
                // 玩家点击取消按钮时，退出该状态
                
                // [攻击确认状态]
                // 预览本次攻击效果并进入攻击
                // - 如果点击确认，则执行指令。
                // - 如果点击取消，则退出该状态
                
                // if (hitInfo != null)
                // {
                //     // 获取射线碰撞的对象
                //     var go = hitInfo.collider.gameObject;
                //     
                //     // TODO 添加格子上的物体被点击时同样可以选中该地格
                //     var grid = go.GetComponent<GridController>();
                //     if (grid != null)
                //     {
                //         if (grid) // TODO 首先判断有没有选中玩家且选中的格子在玩家的移动范围内
                //         {
                //             // TODO 显示角色移动后的剪影，此时会记录角色的选择位置，点击开始攻击时，攻击范围将以此为基础显示。
                //         }
                //         else
                //         {
                //             GridCtrl?.OnCancelSelected();
                //             GridCtrl = grid;
                //             GridCtrl.OnSelected();
                //         }
                //     }
                // }
                // else
                // {
                //     // TODO 清空一切显示
                // }
            // }
        }

        private void OnCharacterSelected(CharacterUnitController character)
        {
            // TODO 显示角色操作面板
            // TODO 计算显示角色移动范围
        }
        
        private int _selectIndex = 0;

        private void HandleTest()
        {
            // 处理玩家输入
            if (playableCharacters.Count == 0) return;
            if (Input.GetKeyDown(KeyCode.E))
            {
                _selectIndex = (_selectIndex + 1) % playableCharacters.Count;
                Debug.Log($"Selected character: {playableCharacters[_selectIndex].EntityData.StaticData.name}");
            }
            else if (Input.GetKeyDown(KeyCode.Q))
            {
                // 选择上一个角色
                _selectIndex = (_selectIndex - 1 + playableCharacters.Count) % playableCharacters.Count;
                Debug.Log($"Selected character: {playableCharacters[_selectIndex].EntityData.StaticData.name}");
            }
            
            var moveLeft = Input.GetKeyDown(KeyCode.A);
            var moveRight = Input.GetKeyDown(KeyCode.D);
            var moveUp = Input.GetKeyDown(KeyCode.W);
            var moveDown = Input.GetKeyDown(KeyCode.S);
            
            if (moveLeft || moveRight || moveUp || moveDown)
            {
                Vector2Int direction;
                if (moveLeft) direction = Vector2Int.left;
                else if (moveRight) direction = Vector2Int.right;
                else if (moveUp) direction = Vector2Int.up;
                else direction = Vector2Int.down;

                var character = playableCharacters[_selectIndex];
                var gridCoord = character.EntityData.gridCoord;
                character.Teleport(gridCoord + direction);
            }
        }

        private void OnPlayerTurnStart(PlayerTurnEventArgs args)
        {
            _fsm.ChangeState(InputState.Select);
            
            // TODO Delete
            Debug.Log($"Player's turn started for round {args.Round}");
            // 处理玩家回合开始事件
            playableCharacters.Clear();
            _selectIndex = 0;
            var units = ServiceLocator.GetService<IUnitDataProvider>().GetEntities(UnitType.Player);
            foreach (var unit in units)
            {
                if (unit is CharacterUnitController character)
                {
                    playableCharacters.Add(character);
                }
                else
                {
                    Debug.LogWarning($"Unit {unit} is not a playable character.");
                }
            }
        }
    }
}