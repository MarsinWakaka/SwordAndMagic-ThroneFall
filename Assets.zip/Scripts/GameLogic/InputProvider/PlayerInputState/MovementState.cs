using GameLogic.Unit.Controller;
using MyFramework.Utilities.FSM;

namespace GameLogic.InputProvider.PlayerInputState
{
    public class MovementStateParams : IStateParams
    {
        public readonly CharacterUnitController UnitController;

        public MovementStateParams(CharacterUnitController unitController)
        {
            UnitController = unitController;
        }
    }
    
    public class MovementState : IState
    {
        public PlayerInputProvider InputProvider { get; set; }
        
        public void OnEnter(IStateParams stateParams)
        {
            if (stateParams is not MovementStateParams movementStateParams)
            {
                throw new System.ArgumentException("Invalid state parameters for MovementState");
            }
        }

        public void OnUpdate()
        {
            
        }

        public void OnExit()
        {
            throw new System.NotImplementedException();
        }
    }
}