using GameLogic.Grid;
using GameLogic.Unit.Controller;
using MyFramework.Utilities.FSM;
using UnityEngine;

namespace GameLogic.InputProvider.PlayerInputState
{
    public class SelectStateParams : IStateParams
    {
        
    }
    
    public class SelectState : IState
    {
        public PlayerInputProvider InputProvider;

        public SelectState(PlayerInputProvider inputProvider)
        {
            InputProvider = inputProvider;
        }
        
        public void OnEnter(IStateParams stateParams)
        {
            InputProvider.RayCastLayer = InputProvider._groundLayer | InputProvider._entityLayer;
        }
        
        private readonly RaycastHit2D[] _results = new RaycastHit2D[10];
        private int _resultCount;
        private int _curIndex;
        private const int RaycastDistance = 100;
        private GridController _selectedGrid;

        public void OnUpdate()
        {
            InputProvider.ShowMouseHoverStyleOnGrid();
            
            // 滚轮切换选择对象
            if (Input.mouseScrollDelta.y != 0)
            {
                if (_resultCount <= 0) return;
                _curIndex += (int)Input.mouseScrollDelta.y > 0 ? 1 : -1;
                _curIndex = Mathf.Clamp(_curIndex, 0, _resultCount - 1);
                HandleRaycastInfo(_results[_curIndex]);
            }
            
            if (Input.GetMouseButtonDown(0))
            {
                // 1. 将鼠标屏幕坐标转换为世界坐标
                Vector2 mouseWorldPos = InputProvider._viewCamera.ScreenToWorldPoint(Input.mousePosition);
            
                // 2. 定义射线方向（从鼠标位置沿摄像机前方发射）
                Vector2 rayDirection = InputProvider._viewCamera.transform.forward; // 2D中通常用 Vector2.right 或自定义方向
            
                // 3. 执行射线检测
                _resultCount = Physics2D.RaycastNonAlloc(
                    origin: mouseWorldPos,
                    direction: rayDirection,
                    results: _results,
                    distance: RaycastDistance,
                    layerMask: InputProvider.RayCastLayer
                );

                // 4. 调试绘制射线（可视化）
                Debug.DrawRay(mouseWorldPos, rayDirection * RaycastDistance, Color.red, 1f);
                
                if (_resultCount <= 0) return;
                HandleRaycastInfo(_results[_resultCount - 1]);
            }
        }

        private void HandleRaycastInfo(RaycastHit2D hitInfo)
        {
            if (hitInfo.collider != null)
            {
                var unit = hitInfo.collider.GetComponent<CharacterUnitController>();
                if (unit != null && unit.canAction)
                {
                    unit.OnSelected();
                    return;
                }
                
                var gridCtrl = hitInfo.collider.GetComponent<GridController>();
                if (gridCtrl != null)
                {
                    _selectedGrid?.OnCancelMouseClicked();
                    _selectedGrid = gridCtrl;
                    _selectedGrid.OnMouseClicked();
                }
            }
        }

        public void OnExit()
        {
            // TODO 清空鼠标悬停在格子上时的样式
            _selectedGrid?.OnCancelMouseClicked();
            _selectedGrid = null;
            
            // // TODO 清空选中角色
            // var unit = InputProvider._curSelectedUnit;
            // if (unit != null)
            // {
            //     unit.OnUnSelected();
            //     InputProvider._curSelectedUnit = null;
            // }
        }
    }
}