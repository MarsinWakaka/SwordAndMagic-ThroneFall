using UnityEngine;

namespace GameLogic
{
    public abstract class UpgradableData
    { 
        /// <summary>
        /// 0 - unlearned, 1 ~ n - skill level
        /// </summary>
        [Header("当前等级")]
        public int curLevel;
        [Header("升级数据表")]
        public UpgradeRecord[] upgradeData;

        public int GetUpgradeCost() => upgradeData[curLevel].cost;
        /// <summary>
        /// 升级技能，返回升级所需的素材数量
        /// </summary>
        public void Upgrade()
        {
            if (curLevel == upgradeData.Length - 1) return;
            SetValues(upgradeData[++curLevel].values);
        }

        /// <summary>
        /// 撤销技能升级，返回退还的素材数量
        /// </summary>
        public int Downgrade()
        {
            if (curLevel == 0) return 0;
            SetValues(upgradeData[--curLevel].values);
            return upgradeData[curLevel].cost;
        }

        protected abstract void SetValues(int[] values);
    }
}