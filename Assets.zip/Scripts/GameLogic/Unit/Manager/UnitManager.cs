using System.Collections.Generic;
using Events;
using Events.Battle;
using GameLogic.Unit.Controller;
using MyFramework.Utilities;
using UnityEngine;
using IServiceProvider = MyFramework.Utilities.IServiceProvider;

namespace GameLogic.Unit.Manager
{
    public interface IUnitDataProvider : IServiceProvider
    {
        List<EntityController> GetEntities(UnitType unitType);
        int GetCount(UnitType unitType);
    }
    
    public class UnitManager : MonoBehaviour, IUnitDataProvider
    {
        private readonly Dictionary<UnitType, List<EntityController>> _unitDict = new();
        
        private void OnEnable()
        {
            // 初始化单位管理器
            EventBus.Channel(Channel.Battle).Subscribe<UnitSpawnedEvent>(GameEvent.UnitSpawn, OnUnitSpawned);
            EventBus.Channel(Channel.Battle).Subscribe<UnitDespawnEvent>(GameEvent.UnitDespawn, OnUnitDespawn);
        }
        
        private void OnDisable()
        {
            EventBus.Channel(Channel.Battle).Unsubscribe<UnitSpawnedEvent>(GameEvent.UnitSpawn, OnUnitSpawned);
            EventBus.Channel(Channel.Battle).Unsubscribe<UnitDespawnEvent>(GameEvent.UnitDespawn, OnUnitDespawn);
        }
        
        private void OnUnitSpawned(UnitSpawnedEvent args)
        {
            // 处理单位生成事件
            var unit = args.Unit;
            var unitType = unit.EntityData.StaticData.unitType;
            if (!_unitDict.ContainsKey(unitType))
            {
                _unitDict[unitType] = new List<EntityController>();
            }
            _unitDict[unitType].Add(unit);
        }
        
        private void OnUnitDespawn(UnitDespawnEvent args)
        {
            // 处理单位销毁事件
            var unit = args.Unit;
            var unitType = unit.EntityData.StaticData.unitType;
            if (_unitDict.ContainsKey(unitType))
            {
                _unitDict[unitType].Remove(unit);
                if (_unitDict[unitType].Count == 0)
                {
                    _unitDict.Remove(unitType);
                }
            }
        }

        public List<EntityController> GetEntities(UnitType unitType)
        {
            if (_unitDict.TryGetValue(unitType, out var unitList)) {
                return unitList;
            }
            _unitDict[unitType] = new List<EntityController>();
            return _unitDict[unitType];
        }

        public int GetCount(UnitType unitType)
        {
            if (_unitDict.TryGetValue(unitType, out var unitList))
            {
                return unitList.Count;
            }
            return 0;
        }
    }
}