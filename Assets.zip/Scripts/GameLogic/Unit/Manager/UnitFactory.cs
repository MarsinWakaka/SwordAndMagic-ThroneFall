using System.Collections.Generic;
using Events;
using Events.Battle;
using GameLogic.Map;
using GameLogic.Unit.Controller;
using GameLogic.Unit.Data;
using MyFramework.Utilities;
using UnityEngine;

namespace GameLogic.Unit.Manager
{
    public class UnitFactory : MonoBehaviour
    {
        private Transform _unitRoot;
        private const string UnitResourcePath = "Units/";
        private readonly Dictionary<string, EntityStaticData> _unitDataDict = new ();

        private void Awake()
        {
            _unitRoot = transform;
            var unitDataList = Resources.LoadAll<EntityStaticData>(UnitResourcePath);
            foreach (var data in unitDataList)
            {
                _unitDataDict.Add(data.unitName, data);
            }
        }
        
        private void OnEnable()
        {
            // 初始化单位管理器
            EventBus.Channel(Channel.Battle).Subscribe<LoadUnitRequest>(GameEvent.UnitSpawnRequest, OnUnitSpawn);
        }
        
        private void OnDisable()
        {
            EventBus.Channel(Channel.Battle).Unsubscribe<LoadUnitRequest>(GameEvent.UnitSpawnRequest, OnUnitSpawn);
        }

        private void OnUnitSpawn(LoadUnitRequest args)
        {
            // 处理单位生成事件
            foreach (var request in args.UnitSpawnRequests)
            {
                Create(request);
            }
        }

        public EntityController Create(SpawnUnitRecord spawnUnitRecord)
        {
            var coordinate = spawnUnitRecord.gridCoord;
            var faceDir = spawnUnitRecord.direction;
            if (_unitDataDict.TryGetValue(spawnUnitRecord.unitName, out var unitData))
            {
                // 获取控制器类型
                // var controllerType = Type.GetType(unitData.controllerType);
                var unitController = Instantiate(unitData.prefab, _unitRoot).GetComponent<EntityController>();
                
                unitController.Initialize(unitData, coordinate, faceDir);
                return unitController;
            }

            Debug.LogError($"UnitData not found: {spawnUnitRecord.unitName}");
            return null;
        }
    }
}