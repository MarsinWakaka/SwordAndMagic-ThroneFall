using UnityEngine;

namespace GameLogic.Unit
{
    public interface ITurnAble
    {
        public void OnTurnStart();
    }
    
    public interface IMoveable
    {
        void Move(Vector2Int newGridCoord);
    }
    
    public interface IDamageable
    {
        void TakeDamage(int damage);
    }
}