using System.Collections;
using Events;
using Events.Battle;
using GameLogic.Grid;
using GameLogic.TriggerSystem;
using GameLogic.Unit.Data;
using MyFramework.Utilities;
using UnityEngine;

namespace GameLogic.Unit.Controller
{
    [RequireComponent(typeof(Animator), typeof(SpriteRenderer))]
    public class CharacterUnitController : EntityController
    {
        public override EntityData EntityData => characterData;
        public CharacterData characterData;
        public bool canAction = true;
        public bool IsDead => characterData.CurHp.Value <= 0;
        
        public override void Initialize(EntityStaticData entityStaticData, Vector2Int gridCoord, Direction dir)
        {
            characterData = new CharacterData((CharacterStaticData)entityStaticData, gridCoord, dir);
            base.Initialize(entityStaticData, gridCoord, dir);
        }
        
        public IEnumerator Move(Vector2Int newGridCoord)
        {
            var triggerService = ServiceLocator.GetService<ITriggerService>();
            var oldGridCoord = characterData.gridCoord;
            
            // 查询触发器服务，触发关于离开区域的触发器
            yield return triggerService.HandleCharacterLeaveArea(this, oldGridCoord);
            if (IsDead) yield break;
            
            // 移动单位, 并通知位置变化
            var height = ServiceLocator.GetService<IGridDataProvider>().QueryHeight(newGridCoord);
            Trans.position = CoordinateConverter.ToEntityWorldPos(new Vector3Int(newGridCoord.x, newGridCoord.y, height));
            EventBus.Channel(Channel.Battle).Publish(GameEvent.UnitMove, 
                new UnitMoveArgs(this, oldGridCoord, newGridCoord));
            
            // 查询触发器服务，触发关于进入区域的触发器
            yield return triggerService.HandleCharacterEnterArea(this, newGridCoord);
            yield return null;
        }

        public void OnSelected()
        {
            Debug.Log($"选中单位: {characterData.StaticData.name}");
        }
    }
}