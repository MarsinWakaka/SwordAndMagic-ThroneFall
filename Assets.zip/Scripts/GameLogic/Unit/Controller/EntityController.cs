using Events;
using Events.Battle;
using GameLogic.Grid;
using GameLogic.Unit.Data;
using MyFramework.Utilities;
using UnityEngine;

namespace GameLogic.Unit.Controller
{
    public abstract class EntityController : MonoBehaviour
    {
        protected Transform Trans;
        protected Animator Anim;
        protected SpriteRenderer Renderer;

        public abstract EntityData EntityData { get; }


        public virtual void Initialize(EntityStaticData entityStaticData, Vector2Int gridCoord, Direction direction)
        {
            Teleport(gridCoord);
            // TODO 通知UnitManager单位生成
            EventBus.Channel(Channel.Battle).Publish(GameEvent.UnitSpawn, new UnitSpawnedEvent(this));
        }
        
        protected virtual void Awake()
        {
            Trans = transform;
            Anim = GetComponent<Animator>();
            Renderer = GetComponent<SpriteRenderer>();
        }
        
        /// <summary>
        /// 传送单位到指定位置
        /// </summary>
        public void Teleport(Vector2Int newGridCoord)
        {
            var height = ServiceLocator.GetService<IGridDataProvider>().QueryHeight(newGridCoord);
            var oldGridCoord = EntityData.gridCoord;
            EntityData.gridCoord = newGridCoord;
            Trans.position = CoordinateConverter.ToEntityWorldPos(new Vector3Int(newGridCoord.x, newGridCoord.y, height));
            // NotifyPositionChange(oldGridCoord, newGridCoord);
            // TODO
            // 1.告知GirdSystem单位位置更新
            EventBus.Channel(Channel.Battle).Publish(GameEvent.UnitMove, new UnitMoveArgs(this, oldGridCoord, newGridCoord));
        }

        public virtual void Destroy()
        {
            
        }
    }
}