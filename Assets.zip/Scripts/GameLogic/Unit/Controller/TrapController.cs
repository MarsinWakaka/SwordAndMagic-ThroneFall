using GameLogic.Unit.Data;
using UnityEngine;

namespace GameLogic.Unit.Controller
{
    public class TrapController : EntityController
    {
        public override EntityData EntityData => trapData;
        public TrapData trapData;
        public override void Initialize(EntityStaticData entityStaticData, Vector2Int gridCoord, Direction direction)
        {
            trapData = new TrapData((TrapStaticData)entityStaticData, gridCoord, direction);
            base.Initialize(entityStaticData, gridCoord, direction);
        }
    }
}