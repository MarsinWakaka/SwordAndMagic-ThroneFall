using GameLogic.Unit.Data;
using UnityEngine;

namespace GameLogic.Unit.Controller
{
    public class ObstacleController : EntityController
    {
        public override EntityData EntityData => obstacleData;
        public ObstacleData obstacleData;
        public override void Initialize(EntityStaticData entityStaticData, Vector2Int gridCoord, Direction direction)
        {
            obstacleData = new ObstacleData((ObstacleStaticData)entityStaticData, gridCoord, direction);
            base.Initialize(entityStaticData, gridCoord, direction);
        }
    }
}