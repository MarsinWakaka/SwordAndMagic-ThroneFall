using System;
using UnityEngine;
using UnityEngine.Serialization;

namespace GameLogic.Unit.Data
{
    [Serializable]
    public class TrapData : EntityData
    {
        public override EntityStaticData StaticData => obstacleStaticData;
        public TrapStaticData obstacleStaticData;

        public TrapData(TrapStaticData trapData, Vector2Int gridCoord, Direction dir)
            : base(gridCoord, dir) {
            obstacleStaticData = trapData;
        }
    }
}