using System.Collections.Generic;
using GameLogic.Skill;
using UnityEngine;

namespace GameLogic.Unit.Data
{
    [CreateAssetMenu(menuName = "Unit/CharacterData")]
    public class CharacterStaticData : EntityStaticData
    {
        [Header("基础属性 1. HP 2. MoveRange")]
        public List<UpgradeRecord> upgradeRecords;
        public List<BaseSkill> skills;
    }
}