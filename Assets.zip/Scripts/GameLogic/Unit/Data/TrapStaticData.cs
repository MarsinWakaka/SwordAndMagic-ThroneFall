using UnityEngine;

namespace GameLogic.Unit.Data
{
    [CreateAssetMenu(menuName = "Unit/TrapData")]
    public class TrapStaticData : EntityStaticData
    {
        public int damage;
        public Vector2Int[] impactScope = {Vector2Int.zero};
    }
}