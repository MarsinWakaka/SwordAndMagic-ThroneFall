using UnityEngine;

namespace GameLogic.Unit.Data
{
    [CreateAssetMenu(menuName = "Unit/ObstacleData")]
    public class ObstacleStaticData : EntityStaticData
    {
        public bool isDestructible;
        public int maxDurability;
        
        [Tooltip("角色是否可以站在障碍物上")]
        public bool canStandOn;
        [Tooltip("障碍物的高度")]
        public int height;
    }
}