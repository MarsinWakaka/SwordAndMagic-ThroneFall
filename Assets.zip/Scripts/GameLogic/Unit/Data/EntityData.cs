using System;
using UnityEngine;

namespace GameLogic.Unit.Data
{
    [Serializable]
    public abstract class EntityData
    {
        public abstract EntityStaticData StaticData { get; }
        
        public Direction dir;
        public Vector2Int gridCoord;

        protected EntityData(Vector2Int gridCoord, Direction dir)
        {
            this.dir = dir;
            this.gridCoord = gridCoord;
        }
    }
}