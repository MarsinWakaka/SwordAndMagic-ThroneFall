using UnityEngine;

namespace GameLogic.Unit.Data
{
    public abstract class EntityStaticData : ScriptableObject
    {
        public GameObject prefab;
        
        public string unitName;
        public Sprite sprite;
        public UnitType unitType;
        public bool blockMovement;
    }
}