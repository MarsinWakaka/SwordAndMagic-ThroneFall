using System;
using UnityEngine;
using UnityEngine.Serialization;

namespace GameLogic.Unit.Data
{
    [Serializable]
    public class ObstacleData : EntityData
    {
        public override EntityStaticData StaticData => obstacleStaticData;
        public ObstacleStaticData obstacleStaticData;

        public ObstacleData(ObstacleStaticData data, Vector2Int gridCoord, Direction dir)
            : base(gridCoord, dir) {
            obstacleStaticData = data;
        }
    }
}