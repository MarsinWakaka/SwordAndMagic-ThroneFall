using System;
using System.Collections.Generic;
using GameLogic.Skill;
using MyFramework.Utilities;
using UnityEngine;
using UnityEngine.Serialization;

namespace GameLogic.Unit.Data
{
    [Serializable]
    public class CharacterData : EntityData
    {
        public override EntityStaticData StaticData => obstacleStaticData;
        public CharacterStaticData obstacleStaticData;
        public Bindable<int> CurLevel;
        
        public Bindable<int> CurHp;
        public Bindable<int> MaxHp;

        public Bindable<int> CurMoveRange;
        public Bindable<int> MaxMoveRange;
        
        public List<BaseSkill> skills;

        public CharacterData(CharacterStaticData characterData,
            Vector2Int gridCoord, Direction dir)
            : base(gridCoord, dir)
        {
            obstacleStaticData = characterData;
            CurLevel = new Bindable<int>(1);
            CurLevel.OnValueChanged += LevelChanged;
        }

        public void LevelChanged(int newLevel)
        {
            MaxHp = new Bindable<int>(obstacleStaticData.upgradeRecords[CurLevel.Value - 1].values[0]);
            MaxMoveRange = new Bindable<int>(obstacleStaticData.upgradeRecords[CurLevel.Value - 1].values[1]);
            CurHp = new Bindable<int>(MaxHp.Value);
            CurMoveRange = new Bindable<int>(MaxMoveRange.Value);
        }
    }
}