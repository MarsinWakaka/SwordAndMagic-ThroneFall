namespace GameLogic.Unit
{
    public enum UnitType
    {
        None = 0,
        Player = 1,
        Enemy = 2,
        NPC = 4,
        IndestructibleObstacle = 8,     // 无血量、不攻击的单位，例如地形、墙壁、石头
        DestructibleObstacle = 16,      // 有血量、可攻击的单位、例如箱子、栅栏
        Trap = 32,                      // 陷阱、会轮询的单位，例如地雷、炸弹、捕兽夹
    }
}