using MyFramework.Utilities;
using UnityEngine;

namespace GameLogic.Unit
{
    public interface IComponent
    {
        
    }
    
    public class HealthComponent : IComponent
    {
        public Bindable<int> CurrentHp;
        public Bindable<int> MaxHp;

        public HealthComponent(int maxHp)
        {
            MaxHp = new Bindable<int>(maxHp);
            CurrentHp = new Bindable<int>(maxHp);
        }
        
        public void TakeDamage(int damage)
        {
        }
        
        public void Heal(int heal)
        {
        }
    }
    public class MoveComponent : IComponent
    {
        public Bindable<int> CurrentMoveRange;
        public Bindable<int> MaxMoveRange;

        public MoveComponent(int maxMoveRange)
        {
            MaxMoveRange = new Bindable<int>(maxMoveRange);
            CurrentMoveRange = new Bindable<int>(maxMoveRange);
        }
        
        public void Move(Vector2Int newGridCoord)
        {
        }
    }
    
    // public class SkillComponent : IComponent
    // {
    //     public Bindable<int> CurEnergy;
    //     public Bindable<int> MaxEnergy;
    //     
    //     public List<BaseSkill> skills;
    //     
    //     public SkillComponent(List<BaseSkill> skills)
    //     {
    //         this.skills = skills;
    //     }
    // }
}