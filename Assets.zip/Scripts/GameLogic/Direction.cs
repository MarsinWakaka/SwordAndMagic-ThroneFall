namespace GameLogic
{
    public enum Direction
    {
        Up,
        Down,
        Left,
        Right
    }
}