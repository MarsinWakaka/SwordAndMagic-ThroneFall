using UnityEngine;

namespace GameLogic.Map
{
    public class MapLoader
    {
        private static string MapPath => "Maps/"; 
        
        public  MapContext LoadMap(int chapter, int level)
        {
            // 加载地图
            return Resources.Load<MapContext>($"{MapPath}{chapter}_{level}/MapContext");
        }
    }
}