using System;
using System.Collections.Generic;
using GameLogic.Task;
using GameLogic.TimeLine;
using UnityEngine;
using UnityEngine.Serialization;

namespace GameLogic.Map
{
    [Serializable]
    public class SpawnUnitRecord
    {
        public string unitName;
        public Vector2Int gridCoord;
        public Direction direction;
        
        public SpawnUnitRecord(string unitName, Vector2Int gridCoord, Direction direction = Direction.Up)
        {
            this.unitName = unitName;
            this.gridCoord = gridCoord;
            this.direction = direction;
        }
    }
    
    [Serializable]
    public class SpawnGridRecord
    {
        public int cellID;            
        public Vector2Int gridCoord;
        public int height;
    }
    
    [CreateAssetMenu(fileName = "MapContext", menuName = "MapContext", order = 1)]
    public class MapContext  : ScriptableObject
    {
        public List<SpawnGridRecord> grids;
        
        [Header("部署相关")]
        public List<Vector2Int> deployPoints;
        public int maxDeployCount;
        
        [Header("场上障碍物")]
        public List<SpawnUnitRecord> obstacles;
        
        [Header("场上角色")]
        public List<SpawnUnitRecord> characters;
        
        [FormerlySerializedAs("dialogueIndex")] [Header("剧情")]
        public string dialogueId;
    
        [Header("任务部分")]
        public List<BaseTask> tasks;
        
        [Header("时间轴事件")]
        public List<TimeLineEvent> timeLineEvents;
    }
}
