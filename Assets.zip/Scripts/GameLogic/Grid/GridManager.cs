using Events;
using Events.Battle;
using MyFramework.Utilities;
using UnityEngine;
using IServiceProvider = MyFramework.Utilities.IServiceProvider;

namespace GameLogic.Grid
{
    public interface IGridDataProvider : IServiceProvider
    {
        public int QueryHeight(Vector2Int girdCoord);
        public Vector3 QueryUnitWorldPos(Vector2Int gridCoord);
    }
    
    public class GridManager : MonoBehaviour, IGridDataProvider
    {
        public Vector2 gridsSize;
        // private int[,] _gridsID;
        private int[,] _cellHeight;
        private GridData[,] _cellData;
        
        private GridFactory _gridFactory;

        private void Awake()
        {
            _gridFactory = GetComponent<GridFactory>();
            if (_gridFactory == null)
            {
                Debug.LogError("GridFactory component not found on GridManager.");
                return;
            }
        }

        private void OnEnable()
        {
            EventBus.Channel(Channel.Battle).Subscribe<LoadGridRequest>(GameEvent.LoadGridRequest, OnLoadGrid);
        }
        
        private void OnDisable()
        {
            EventBus.Channel(Channel.Battle).Unsubscribe<LoadGridRequest>(GameEvent.LoadGridRequest, OnLoadGrid);
        }

        private void OnLoadGrid(LoadGridRequest loadRequest)
        {
            _gridFactory.Create(loadRequest.Records, out _cellHeight, out _cellData);
        }
        
        public Vector3 QueryUnitWorldPos(Vector2Int gridCoord)
        {
            var height = _cellHeight[gridCoord.x, gridCoord.y];
            return CoordinateConverter.ToEntityWorldPos(gridCoord, height);
        }

        public int QueryHeight(Vector2Int girdCoord) => _cellHeight[girdCoord.x, girdCoord.y];
    }
}