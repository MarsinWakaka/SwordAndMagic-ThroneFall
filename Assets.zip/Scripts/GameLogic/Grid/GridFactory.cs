using System;
using System.Collections.Generic;
using GameLogic.Map;
using UnityEngine;
using UnityEngine.Serialization;

namespace GameLogic.Grid
{
    public class GridFactory : MonoBehaviour
    {
        private const string GridDataPathRoot = "CellData/";

        private readonly Dictionary<int, GridData> _cellDataDict = new();
        
        private Transform _gridsRoot;
        [SerializeField] private GridController gridPrefab;

        private void Awake()
        {
            _gridsRoot = transform;
            var cellDataList = Resources.LoadAll<GridData>(GridDataPathRoot);
            foreach (var cellData in cellDataList)
            {
                if (!_cellDataDict.TryAdd(cellData.CellID, cellData))
                {
                    Debug.LogError($"Duplicate cell ID found:\n{cellData}\n{_cellDataDict[cellData.CellID]}");
                }
            }
        }

        public GridData QueryCellData(int cellID)
        {
            if (_cellDataDict.TryGetValue(cellID, out var data))
            {
                return data;
            }
            Debug.LogError($"CellData not found for ID: {cellID}");
            return null;
        }
        
        public void Create(List<SpawnGridRecord> grids, out int[,] cellHeight, out GridData[,] cellData)
        {
            // Initialize the grid factory
            _gridsRoot = transform;
            Vector2 gridsSize = Vector2.zero;
            foreach (var grid in grids)
            {
                gridsSize.x = Mathf.Max(gridsSize.x, grid.gridCoord.x + 1);
                gridsSize.y = Mathf.Max(gridsSize.y, grid.gridCoord.y + 1);
            }
            var maxCol = (int) gridsSize.x;
            var maxRow = (int) gridsSize.y;
            
            // _gridsID = new int[maxCol, maxRow];
            cellHeight = new int[maxCol, maxRow];
            cellData = new GridData[maxCol, maxRow];
            
            foreach (var grid in grids)
            {
                // _gridsID[grid.gridCoord.x, grid.gridCoord.y] = grid.cellID;
                cellHeight[grid.gridCoord.x, grid.gridCoord.y] = grid.height;
                cellData[grid.gridCoord.x, grid.gridCoord.y] = QueryCellData(grid.cellID);
            }
            
            for (var x = 0; x < maxCol; x++)
            {
                for (var y = 0; y < maxRow; y++)
                {
                    var cell = Instantiate(gridPrefab, _gridsRoot);
                    var worldPos = CoordinateConverter.ToEntityWorldPos(new Vector2Int(x, y), cellHeight[x,y]);
                    cell.Initialize(cellData[x,y], worldPos);
                }
            }
        }
    }
}