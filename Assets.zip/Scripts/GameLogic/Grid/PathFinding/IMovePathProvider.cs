using UnityEngine;

namespace GameLogic.Grid.PathFinding
{
    public interface IMovePathProvider
    {
        public MovePath FindPath(Vector2Int start, Vector2Int end);
    }
    
    public class AStar : IMovePathProvider
    {
        public MovePath FindPath(Vector2Int start, Vector2Int end)
        {
            throw new System.NotImplementedException();
        }
    }
}