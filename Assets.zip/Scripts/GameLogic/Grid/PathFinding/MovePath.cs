using System.Collections.Generic;
using UnityEngine;

namespace GameLogic.Grid.PathFinding
{
    public class MovePath
    {
        public List<Vector2Int> PathNode;
    }
}