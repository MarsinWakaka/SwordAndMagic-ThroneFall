using System.Collections.Generic;
using UnityEngine;

namespace GameLogic.Grid
{
    public enum GridState
    {
        Normal,
        Hover,
        Selected,
    }
    
    [RequireComponent(typeof(SpriteRenderer))]
    public class GridController : MonoBehaviour
    {
        private static readonly Vector3 CenterOffset = new Vector3(0, -0.25f, 0);
        private Transform _transformCache; 
        private SpriteRenderer _spriteRenderer;
        
        public GridData GridData { get; private set; }
        private List<CharacterController> _unitsOnGrid = new();
        
        private GridState _gridState;
        
        private void Awake()
        {
            _transformCache = transform;
            _spriteRenderer = GetComponent<SpriteRenderer>();
        }

        public Vector3 CenterPosition
        {
            get => _transformCache.position + CenterOffset;
            set => _transformCache.position = value - CenterOffset;
        }
        
        public void Initialize(GridData gridData, Vector3 worldPos)
        {
            GridData = gridData;
            _spriteRenderer.sprite = gridData.CellSprite;
            _spriteRenderer.drawMode = SpriteDrawMode.Tiled;
            _spriteRenderer.size = new Vector2(1, 1 + worldPos.z * 0.25f);
            
            CenterPosition = worldPos;
        }
        
        public void OnUnitEnter(CharacterController unit)
        {
            // TODO
        }
        
        public void OnUnitExit(CharacterController unit)
        {
            // TODO
        }

        public void OnMouseHover()
        {
            if (_gridState == GridState.Selected) return;
            _gridState = GridState.Hover;
            _spriteRenderer.color = new Color(1, 1, 1, 0.7f);
        }

        public void OnCancelMouseHover()
        {
            if (_gridState == GridState.Selected) return;
            _gridState = GridState.Normal;
            _spriteRenderer.color = new Color(1, 1, 1, 1);
        }

        public void OnMouseClicked()
        {
            _gridState = GridState.Selected;
            _spriteRenderer.color = new Color(.4f, .4f, 1f, 1f);
        }

        public void OnCancelMouseClicked()
        {
            _gridState = GridState.Normal;
            _spriteRenderer.color = new Color(1, 1, 1, 1);
        }
    }
}