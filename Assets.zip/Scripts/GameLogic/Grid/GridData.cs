using UnityEngine;

namespace GameLogic.Grid
{
    [CreateAssetMenu(fileName = "NewCellData", menuName = "CellData", order = 0)]
    public class GridData : ScriptableObject
    {
        [SerializeField] private int cellID;
        [SerializeField] private string cellName;
        [SerializeField] private Sprite cellSprite;
        [SerializeField] private bool blockMovement;
        
        public int CellID => cellID;
        public string CellName => cellName;
        public Sprite CellSprite => cellSprite;
        public bool BlockMovement => blockMovement;
        
        public override string ToString()
        {
            return $"Cell ID: {cellID}, Name: {cellName}";
        }
    }
}