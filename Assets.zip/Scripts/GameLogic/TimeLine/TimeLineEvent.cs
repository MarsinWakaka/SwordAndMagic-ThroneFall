using System.Collections;
using UnityEngine;

namespace GameLogic.TimeLine
{
    public abstract class TimeLineEvent : ScriptableObject
    {
        public TriggerCondition triggerCondition;
        public abstract IEnumerator Execute();
    }
}