using UnityEngine;

namespace GameLogic.TimeLine
{
    public abstract class BaseEventData : ScriptableObject
    {
        
    }
}