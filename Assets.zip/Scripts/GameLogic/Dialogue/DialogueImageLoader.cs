using Events;
using Events.Battle;
using MyFramework.Utilities;
using UnityEngine;

namespace GameLogic.Dialogue
{
    public class DialogueImageLoader : MonoBehaviour
    {
        private const string ExpressionPath = "Dialogues/Expressions/";
        private const string BgPath = "Dialogues/Background/";
        
        private void OnEnable()
        {
            // TODO : 订阅事件
            EventBus.Channel(Channel.Battle).
                Subscribe<CharacterExpressionRequest>(GameEvent.CharacterExpressionRequest, HandleExpressionRequest);
            EventBus.Channel(Channel.Battle).
                Subscribe<DialogueImageRequest>(GameEvent.DialogueImageRequest, HandleBgImageRequest);
        }

        private void OnDisable()
        {
            // TODO : 注销事件
            EventBus.Channel(Channel.Battle).
                Unsubscribe<CharacterExpressionRequest>(GameEvent.CharacterExpressionRequest, HandleExpressionRequest);
            EventBus.Channel(Channel.Battle).
                Unsubscribe<DialogueImageRequest>(GameEvent.DialogueImageRequest, HandleBgImageRequest);
        }
        
        private void HandleExpressionRequest(CharacterExpressionRequest request)
        {
            var image = Load<Sprite>($"{ExpressionPath}{request.CharacterName}_{request.Expression}");
            if (image != null) request.OnImageReady?.Invoke(image);
        }

        private void HandleBgImageRequest(DialogueImageRequest request)
        {
            var bg = Load<Sprite>(BgPath + request.ImageName);
            if (bg != null) request.OnImageReady?.Invoke(bg);
        }

        private T Load<T>(string fullPath) where T : Object
        {
            T result = Resources.Load<T>(fullPath);
            if (result == null)
            {
                Debug.LogError($"资源加载失败{fullPath} : {typeof(T)}");
            }
            return result;
        }
    }
}