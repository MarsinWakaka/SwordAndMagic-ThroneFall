using System;
using System.Collections.Generic;

namespace MyFramework.Utilities
{
    // 通道类型枚举（或字符串标识）
    public enum Channel
    {
        UI,
        Battle,
        Global
    }

    // 基础事件参数
    public interface IEventArgs { }
    
    // 事件通道类
    public class EventChannel
    {
        private readonly Dictionary<string, Delegate> _eventHandlers = new();

        public void Subscribe<T>(string gameEvent, Action<T> handler) where T : IEventArgs
        {
            if (!_eventHandlers.TryAdd(gameEvent, handler))
            {
                _eventHandlers[gameEvent] = Delegate.Combine(_eventHandlers[gameEvent], handler);
            }
        }

        public void Unsubscribe<T>(string gameEvent, Action<T> handler) where T : IEventArgs
        {
            if (_eventHandlers.TryGetValue(gameEvent, out var existingHandler))
            {
                _eventHandlers[gameEvent] = Delegate.Remove(existingHandler, handler);
            }
        }

        public void Publish<T>(string gameEvent, T args) where T : IEventArgs
        {
            if (_eventHandlers.TryGetValue(gameEvent, out var handlers))
            {
                (handlers as Action<T>)?.Invoke(args);
            }
        }
    }

    // 事件系统入口
    public static class EventBus
    {
        private static readonly Dictionary<Channel, EventChannel> Channels = new();

        public static EventChannel Channel(Channel channel)
        {
            if (!Channels.ContainsKey(channel))
            {
                Channels[channel] = new EventChannel();
            }
            return Channels[channel];
        }
    }
}