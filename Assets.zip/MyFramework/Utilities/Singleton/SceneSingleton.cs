using UnityEngine;
using UnityEngine.SceneManagement;

namespace MyFramework.Utilities.Singleton
{
    /// <summary>
    /// 场景级自动销毁单例
    /// 特性：随场景卸载自动销毁、线程安全
    /// </summary>
    public abstract class SceneSingleton<T> : MonoBehaviour where T : SceneSingleton<T>
    {
        private static T _instance;
        private static readonly object _lock = new object();
        private static Scene _registeredScene;

        public static T Instance
        {
            get
            {
                if (_instance != null) return _instance;
                
                lock (_lock) 
                {
                    if (_instance == null) 
                    {
                        // 场景检查
                        var currentScene = SceneManager.GetActiveScene();
                        if (_registeredScene != currentScene) {
                            Debug.LogError($"[SceneSingleton] 跨场景访问禁止！当前场景：{currentScene.name}");
                            return null;
                        }

                        _instance = FindObjectOfType<T>();
                        if (_instance == null) {
                            GameObject obj = new GameObject($"{typeof(T).Name}_SceneSingleton");
                            _instance = obj.AddComponent<T>();
                        }
                    }
                    return _instance;
                }
            }
        }

        protected virtual void Awake()
        {
            lock (_lock) {
                if (_instance != null && _instance != this) {
                    Destroy(gameObject);
                    return;
                }

                _instance = this as T;
                _registeredScene = gameObject.scene;

                // 注册场景卸载事件
                SceneManager.sceneUnloaded += OnSceneUnloaded;
            }
        }

        private void OnSceneUnloaded(Scene unloadedScene)
        {
            if (unloadedScene == _registeredScene) {
                SceneManager.sceneUnloaded -= OnSceneUnloaded;
                Destroy(gameObject);
            }
        }

        protected virtual void OnDestroy()
        {
            lock (_lock) {
                if (_instance == this) {
                    _instance = null;
                    _registeredScene = default;
                }
            }
        }
    }
}